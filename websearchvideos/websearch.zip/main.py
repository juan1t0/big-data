"""
https://cloud.google.com/functions/docs/tutorials/storage?authuser=1
https://cloud.google.com/sql/docs/mysql/quickstart-connect-functions?hl=es-419
"""

"""HTTP Cloud Function.
Args:
    request (flask.Request): The request object.
    <https://flask.palletsprojects.com/en/1.1.x/api/#incoming-request-data>
Returns:
    The response text, or any set of values that can be turned into a
    Response object using `make_response`
    <https://flask.palletsprojects.com/en/1.1.x/api/#flask.make_response>.
"""

# https://www.google.com/search?q=google+cloud+function+read+video+from+cloud+storage+python&rlz=1C1SQJL_esPE861PE862&oq=google+cloud+function+read+video+from+cloud+storage+python&aqs=chrome..69i57j69i64.9906j0j7&sourceid=chrome&ie=UTF-8
# https://docs.sqlalchemy.org/en/13/core/tutorial.html
# https://cloud.google.com/sql/docs/mysql/quickstart-connect-functions


from flask import Flask#, request #import main Flask class and request object
from flask import render_template as render

import sqlalchemy

connection_name = "clouducsp:us-central1:taggedmedia"
db_password = "root"
db_name = "clouducsp"
db_user = "root"
driver_name = 'mysql+pymysql'
query_string = dict({"unix_socket": "/cloudsql/{}".format(connection_name)})

db = sqlalchemy.create_engine(sqlalchemy.engine.url.URL(drivername=driver_name,
                                                          username=db_user,
                                                          password=db_password,
                                                          database=db_name,
                                                          query=query_string,),
                                pool_size=5,
                                max_overflow=2,
                                pool_timeout=30,
                                pool_recycle=1800)

yt_base= "https://www.youtube.com/watch?v="

class Video:
  def __init__(self, name, confidence, ytlink):
    self.name=name
    self.confidence = confidence
    self.ytlink = ytlink

def get_videos(word):
  meta = sqlalchemy.MetaData(bind=None)
  table = sqlalchemy.Table('entries',meta, autoload=True, autoload_with=db)
  classNames = { 'background': table.c.LB00,
    'aeroplane': table.c.LB01,'plane': table.c.LB01,'avion': table.c.LB01,
    'bicycle': table.c.LB02,'bicicleta': table.c.LB02,
    'bird': table.c.LB03,'ave': table.c.LB03,'pajaro': table.c.LB03,
    'boat': table.c.LB04,'bote': table.c.LB04,
    'bottle': table.c.LB05,'botella': table.c.LB05,
    'bus': table.c.LB06,'autobus': table.c.LB06,
    'car': table.c.LB07,'carro': table.c.LB07,'auto': table.c.LB07,
    'cat': table.c.LB08,'gato': table.c.LB08,
    'chair': table.c.LB09,'silla': table.c.LB09,
    'cow': table.c.LB10,'vaca': table.c.LB10,
    'diningtable': table.c.LB11,'table': table.c.LB11,'mesa': table.c.LB11,'cena': table.c.LB11,
    'dog': table.c.LB12,'perro': table.c.LB12,
    'horse': table.c.LB13,'caballo': table.c.LB13,
    'motorbike': table.c.LB14,'moto': table.c.LB14,'motocicleta': table.c.LB14,
    'person': table.c.LB15,'persona': table.c.LB15,
    'pottedplant': table.c.LB16,'plant': table.c.LB16,'maceta': table.c.LB16,
    'sheep': table.c.LB17,'oveja': table.c.LB17,
    'sofa': table.c.LB18,'sillon': table.c.LB18,
    'train': table.c.LB19,'tren': table.c.LB19,
    'tvmonitor': table.c.LB20,'tv': table.c.LB20,'monitor': table.c.LB20,'pantalla': table.c.LB20,
  }
  stmt = sqlalchemy.select([table]).where(classNames[word] > 0.0)
  videos = []
  try:
    with db.connect() as conn:
      # res = conn.execute(stmt)
      for r in conn.execute(stmt):
        v = Video(word,r[classNames[word]],yt_base+word)
        videos.append(v)
  except Exception as e:
    print('Error: {}'.format(str(e)))
  
  return videos

def get_result(word):
  videos = get_videos(word)
  return render('result.html', word=word, videos=videos)

# @app.route('/', methods=['GET', 'POST']) #allow both GET and POST requests
def search(request):
  if request.method == 'POST':
    word = request.form.get('keyword')
    return get_result(word)

  return render('index.html')

# if __name__ == '__main__':
#   # app.run(debug=True, port=5000) #run app in debug mode on port 5000
#   app.run(debug=True,host='0.0.0.0',port=int(os.environ.get('PORT', 8080)))


